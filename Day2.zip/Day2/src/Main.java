public class Main  extends Dog{
    public static void main(String[] args) {
     Dog dog=new Dog();
     dog.sound();
     Cat cat=new Cat();
     cat.sound();
    }
}