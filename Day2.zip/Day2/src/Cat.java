public class Cat extends AnimalAbstract{

    @Override
    void sound() {
        System.out.println("Cat's Sound : Meow");

    }
}
