abstract public class AnimalAbstract {
    abstract void sound();

    void sleep() {
        System.out.println("Sleeping..!!!!");
    }
}
