public class Dog extends AnimalAbstract{

    @Override
    void sound() {
        System.out.println("Dog's Sound : Bark");
    }
}
